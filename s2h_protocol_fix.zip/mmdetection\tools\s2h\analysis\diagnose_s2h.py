#!/usr/bin/env python
# Copyright (c) S2H-CD-FSOD. All rights reserved.
"""Measure what the S2H correction actually does, without training anything.

The ablation says "the four stages are within +-0.5 mAP of the baseline", but
that only tells us the *outcome*.  This script opens the correction itself: for
one checkpoint and several knowledge configurations it records, over the test
images,

* ``mean|delta|`` / ``max|delta|``  - is the correction non-zero at all?
* ``mean alpha``                    - the learned class-wise strength
* ``mean u`` / ``active ratio``     - how many queries the router grants authority
* ``mean r_bar``                    - the reliability the knowledge file carries

and turns the numbers into one of three verdicts:

    delta ~ 0                     -> S2H never acted (the initial alpha of the
                                     earlier runs was 1.7e-4, and Eq. (13) keeps
                                     it there)
    delta non-zero, mAP flat      -> the knowledge / routing direction is wrong
    delta non-zero, mAP improves  -> the fix is in the training loop (loss or
                                     optimizer), not in the formulation

Pass the *same* checkpoint to every stage (see ``--stages``): that isolates the
injection (knowledge + stage) from the detector weights, which is exactly the
first experiment the diagnosis asks for.  ``alpha`` and ``g`` are recomputed from
the returned ``u`` / ``r_bar`` and the bank's own parameters, so nothing inside
the model has to change.

Usage
-----
    python tools/s2h/analysis/diagnose_s2h.py \\
        --config configs/s2h_dino/s2h_grounding_dino_swin-b_clipart1k_5shot.py \\
        --checkpoint cat_work_dir/ablation/clipart1k/full/seed3407/5shot/best_*.pth \\
        --knowledge-map "ffcp=work_dirs/s2h_knowledge/ablation/clipart1k/ffcp/seed3407/5shot.pth,\\
ffcp_chsd=work_dirs/s2h_knowledge/ablation/clipart1k/ffcp_chsd/seed3407/5shot.pth,\\
full=work_dirs/s2h_knowledge/ablation/clipart1k/full/seed3407/5shot.pth" \\
        --num-images 100 --json work_dirs/s2h_analysis/diagnose/clipart1k_5shot.json
"""
import argparse
import copy
import json
import os.path as osp
import sys

import numpy as np

sys.path.insert(0, osp.abspath(osp.dirname(__file__)))


def assert_analysis_path(path: str) -> str:
    """Same guard as the other analysis scripts (never the ablation tree)."""
    parts = osp.abspath(path).replace('\\', '/').split('/')
    if 'ablation' in parts or not any(
            r in parts for r in ('s2h_analysis', 'sweep')):
        raise SystemExit(f'refusing to write to {path}')
    return path


# ---------------------------------------------------------------------------
# pure helpers (exercised by --self-check)
# ---------------------------------------------------------------------------
def parse_knowledge_map(text: str, fallback: str = None) -> dict:
    """``"ffcp=a.pth,full=b.pth"`` -> ``{'ffcp': 'a.pth', 'full': 'b.pth'}``.

    A stage that is missing from the map falls back to ``fallback`` (a single
    ``--knowledge``), which is what a quick four-stage probe wants; ``baseline``
    never needs a knowledge file because the bank is switched off for it.
    """
    mapping = {}
    for item in (text or '').replace(' ', '').split(','):
        if not item:
            continue
        if '=' not in item:
            raise SystemExit(f'--knowledge-map expects stage=path, got {item!r}')
        stage, path = item.split('=', 1)
        mapping[stage] = path
    if fallback:
        for stage in ('ffcp', 'ffcp_chsd', 'full'):
            mapping.setdefault(stage, fallback)
    return mapping


def stage_options(stage: str, knowledge: str = None) -> dict:
    """``cfg_options`` for ``init_detector`` that put the head into ``stage``.

    The API wants a *dict* (``Config.merge_from_dict``), unlike the
    ``--cfg-options`` list of ``key=value`` strings that ``tools/train.py``
    takes; passing a list raises ``'list' object has no attribute 'items'``.
    """
    if stage == 'baseline':
        # a vanilla detector: no bank, no knowledge, no routing
        return {'model.bbox_head.s2h_cfg.enabled': False}
    options = {'model.bbox_head.s2h_cfg.enabled': True,
               'model.bbox_head.s2h_cfg.stage': stage}
    if knowledge:
        options['model.bbox_head.s2h_cfg.knowledge_path'] = knowledge
    return options


class Stats:
    """Accumulates the per-call statistics of the ATAR correction."""

    def __init__(self, stage: str):
        self.stage = stage
        self.calls = 0
        self.queries = 0
        self.delta_sum = 0.0
        self.delta_count = 0
        self.delta_max = 0.0
        self.u_sum = 0.0
        self.u_count = 0
        self.active = 0
        self.r_bar_sum = 0.0
        self.r_bar_count = 0
        self.alpha_sum = 0.0
        self.alpha_count = 0
        self.g_sum = 0.0
        self.g_count = 0

    def add(self, delta, u, r_bar, alpha, g_max) -> None:
        delta = np.asarray(delta, np.float64)
        u = np.asarray(u, np.float64).reshape(-1)
        self.calls += 1
        self.queries += int(u.size)
        self.delta_sum += float(np.abs(delta).sum())
        self.delta_count += int(delta.size)
        self.delta_max = max(self.delta_max, float(np.abs(delta).max()))
        self.u_sum += float(u.sum())
        self.u_count += int(u.size)
        self.active += int((u > 0.5).sum())
        r_bar = np.asarray(r_bar, np.float64).reshape(-1)
        self.r_bar_sum += float(r_bar.sum())
        self.r_bar_count += int(r_bar.size)
        alpha = np.asarray(alpha, np.float64).reshape(-1)
        self.alpha_sum += float(alpha.sum())
        self.alpha_count += int(alpha.size)
        # Eq. (11) again, from the returned quantities: g = clamp(u * r_bar)
        g = np.clip(np.asarray(u, np.float64)[:, None]
                    * np.asarray(r_bar, np.float64)[None, :], 0.0, g_max)
        self.g_sum += float(g.sum())
        self.g_count += int(g.size)

    def summary(self) -> dict:
        # delta has one entry per (query, class) per call; the count is
        # accumulated directly, because multiplying the per-call totals would
        # square the number of calls
        delta_mean = (self.delta_sum / self.delta_count
                      if self.delta_count else 0.0)
        return dict(
            stage=self.stage, calls=self.calls, queries=int(self.queries),
            delta_mean_abs=delta_mean, delta_max_abs=self.delta_max,
            u_mean=(self.u_sum / self.u_count) if self.u_count else None,
            active_ratio=(self.active / self.u_count) if self.u_count else None,
            r_bar_mean=(self.r_bar_sum / self.r_bar_count)
            if self.r_bar_count else None,
            alpha_mean=(self.alpha_sum / self.alpha_count)
            if self.alpha_count else None,
            g_mean=(self.g_sum / self.g_count) if self.g_count else None)

    def verdict(self, mAP: float = None, base_mAP: float = None) -> str:
        """One of the three outcomes the diagnosis distinguishes."""
        stats = self.summary()
        if stats['delta_mean_abs'] < 1e-3 and stats['delta_max_abs'] < 1e-2:
            return ('delta ~ 0: the S2H correction never acted - check '
                    'init_alpha_bias / the regularizers, not FFCP or CHSD')
        if mAP is not None and base_mAP is not None:
            if mAP > base_mAP + 0.002:
                return ('delta is non-zero and the mAP improves: the injection '
                        'works on this checkpoint')
            return ('delta is non-zero but the mAP does not move: the knowledge '
                    'or the routing direction is the problem')
        return ('delta is non-zero: compare the mAP of the same checkpoint with '
                'tools/test.py to decide between "direction" and "training loop"')


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        'measure the S2H correction without training')
    parser.add_argument('--config', default=None)
    parser.add_argument('--checkpoint', default=None,
                        help='one checkpoint, used for every stage')
    parser.add_argument('--knowledge', default=None,
                        help='knowledge file used for every non-baseline stage')
    parser.add_argument('--knowledge-map', default='',
                        help="per-stage knowledge, e.g. "
                             "'ffcp=a.pth,ffcp_chsd=b.pth,full=c.pth'")
    parser.add_argument('--stages', nargs='+',
                        default=['baseline', 'ffcp', 'ffcp_chsd', 'full'])
    parser.add_argument('--num-images', type=int, default=100)
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--json', default=None)
    parser.add_argument('--self-check', action='store_true')
    return parser.parse_args(argv)


def self_check() -> int:
    """Exercise the map parser, the option builder and the statistics."""
    mapping = parse_knowledge_map('ffcp=a.pth, full=b.pth', 'fallback.pth')
    assert mapping['ffcp'] == 'a.pth' and mapping['full'] == 'b.pth'
    assert mapping['ffcp_chsd'] == 'fallback.pth', mapping
    assert parse_knowledge_map('', 'x.pth')['full'] == 'x.pth'
    assert parse_knowledge_map('ffcp=a.pth') == {'ffcp': 'a.pth'}
    try:
        parse_knowledge_map('broken')
    except SystemExit:
        pass
    else:
        raise AssertionError('a malformed map was accepted')
    # init_detector wants a dict, not the list that --cfg-options takes
    assert stage_options('baseline') == {
        'model.bbox_head.s2h_cfg.enabled': False}
    full = stage_options('full', 'k.pth')
    assert full['model.bbox_head.s2h_cfg.knowledge_path'] == 'k.pth'
    assert full['model.bbox_head.s2h_cfg.stage'] == 'full'
    assert full['model.bbox_head.s2h_cfg.enabled'] is True

    stats = Stats('full')
    # two calls, three queries each, one class: delta = 0.1 exactly
    for _ in range(2):
        stats.add(delta=np.full((3, 1), 0.1), u=np.array([1.0, 0.0, 0.5]),
                  r_bar=np.array([0.8]), alpha=np.array([0.05]), g_max=0.5)
    summary = stats.summary()
    assert summary['calls'] == 2 and summary['queries'] == 6, summary
    assert abs(summary['delta_mean_abs'] - 0.1) < 1e-9, summary
    assert abs(summary['delta_max_abs'] - 0.1) < 1e-9, summary
    assert abs(summary['u_mean'] - 0.5) < 1e-9, summary
    assert abs(summary['active_ratio'] - 1.0 / 3.0) < 1e-9, summary
    assert abs(summary['alpha_mean'] - 0.05) < 1e-9, summary
    # g = clamp(u * r_bar, max=g_max): 1.0 * 0.8 is clipped to g_max = 0.5,
    # 0.0 stays 0.0, 0.5 * 0.8 = 0.4, so the mean is (0.5 + 0.0 + 0.4) / 3
    assert abs(summary['g_mean'] - (0.5 + 0.0 + 0.4) / 3.0) < 1e-9, summary
    assert stats.verdict().startswith('delta is non-zero'), stats.verdict()
    assert stats.verdict(mAP=0.60, base_mAP=0.55).startswith(
        'delta is non-zero and the mAP improves')
    assert stats.verdict(mAP=0.55, base_mAP=0.55).startswith(
        'delta is non-zero but the mAP does not move')

    silent = Stats('full')
    silent.add(delta=np.zeros((4, 2)), u=np.ones(4), r_bar=np.ones(1),
               alpha=np.zeros(1), g_max=0.5)
    assert silent.verdict().startswith('delta ~ 0'), silent.verdict()
    try:
        assert_analysis_path('cat_work_dir/ablation/x.json')
    except SystemExit:
        pass
    else:
        raise AssertionError('the guard let an ablation path pass')
    print('[self-check] ok')
    return 0


def run(args) -> int:
    import torch
    from mmengine.config import Config
    from mmengine.registry import init_default_scope
    from mmdet.apis import inference_detector, init_detector
    from mmdet.registry import DATASETS

    mapping = parse_knowledge_map(args.knowledge_map, args.knowledge)

    cfg = Config.fromfile(args.config)
    init_default_scope(cfg.get('default_scope', 'mmdet'))
    dataset_cfg = copy.deepcopy(cfg.test_dataloader.dataset)
    dataset_cfg['lazy_init'] = False
    dataset = DATASETS.build(dataset_cfg)

    records = []
    for index in range(len(dataset)):
        info = dataset.get_data_info(index)
        if not [i for i in info.get('instances', [])
                if not i.get('ignore_flag', 0)]:
            continue
        records.append(dict(img_path=info['img_path'],
                            text=info.get('text')
                            or tuple(dataset.metainfo['classes']),
                            custom_entities=bool(
                                info.get('custom_entities', True))))
        if args.num_images > 0 and len(records) >= args.num_images:
            break
    if not records:
        raise SystemExit('no test image with ground truth was found')
    print(f'[diag] {len(records)} images, stages '
          f'{", ".join(args.stages)}')

    report = {}
    for stage in args.stages:
        knowledge = mapping.get(stage) if stage != 'baseline' else None
        if stage != 'baseline' and not knowledge:
            print(f'[warn] no knowledge for stage {stage}; skipping it')
            continue
        model = init_detector(cfg, args.checkpoint, device=args.device,
                             cfg_options=stage_options(stage, knowledge))
        model.eval()
        bank = getattr(model.bbox_head, 's2h_bank', None)
        if bank is None or not model.bbox_head.s2h_active():
            raise SystemExit(
                f'stage {stage}: the S2H bank is not active - wrong '
                'checkpoint or knowledge file?')

        stats = Stats(stage)
        original = bank.atar

        def probe(hidden_states, class_logits, _bank=bank, _stats=stats,
                  _original=original):
            out = _original(hidden_states, class_logits)
            with torch.no_grad():
                _stats.add(delta=out['delta'].detach().cpu().numpy(),
                           u=out['u'].detach().cpu().numpy(),
                           r_bar=out['r_bar'].detach().cpu().numpy(),
                           alpha=_bank.current_alpha().detach().cpu().numpy(),
                           g_max=_bank.g_max)
            return out

        bank.atar = probe
        try:
            with torch.no_grad():
                for record in records:
                    inference_detector(model, record['img_path'],
                                       text_prompt=record['text'],
                                       custom_entities=record['custom_entities'])
        finally:
            bank.atar = original

        summary = stats.summary()
        summary['knowledge'] = knowledge
        summary['verdict'] = stats.verdict()
        report[stage] = summary
        print(f"[diag] {stage:<9s} calls={summary['calls']:<4d} "
              f"queries={summary['queries']:<6d} "
              f"mean|delta|={summary['delta_mean_abs']:.5f} "
              f"max|delta|={summary['delta_max_abs']:.4f} "
              f"alpha={_fmt(summary['alpha_mean'])} "
              f"u={_fmt(summary['u_mean'])} "
              f"active={_fmt(summary['active_ratio'])} "
              f"r_bar={_fmt(summary['r_bar_mean'])}")
        print(f'        -> {summary["verdict"]}')
        del model

    if args.json:
        path = assert_analysis_path(args.json)
        import os
        os.makedirs(osp.dirname(osp.abspath(path)), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(dict(config=args.config, checkpoint=args.checkpoint,
                           images=len(records), stages=report),
                      handle, indent=2, ensure_ascii=False, default=float)
        print(f'[write] {path}')
    return 0


def _fmt(value):
    return 'None' if value is None else f'{value:.4f}'


def main(argv=None) -> int:
    args = parse_args(argv)
    if args.self_check:
        return self_check()
    if not args.config or not args.checkpoint:
        raise SystemExit('--config and --checkpoint are required')
    return run(args)


if __name__ == '__main__':
    sys.exit(main())
