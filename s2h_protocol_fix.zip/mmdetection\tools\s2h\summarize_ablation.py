#!/usr/bin/env python
"""Summarize the four-stage, three-seed S2H ablation.

The script reads MMEngine ``vis_data/scalars.json`` files written by each
training run and writes one row per dataset/stage/shot plus a mean/std
aggregation over seeds.  Missing runs are reported instead of being silently
dropped from the expected 216-run matrix.

Two selection modes:

``--epoch-mode best`` (default)
    The epoch with the largest validation bbox mAP.  Note what that means in
    this project: ``val_dataloader`` points at ``annotations/test.json``, so the
    "validation" mAP *is* the test mAP and the reported number is the best of
    several test evaluations - a test-tuned selection.  The mode is kept only to
    reproduce the earlier tables.

``--epoch-mode fixed``
    The epoch the paper declares in advance (5 for clipart1k / FISH, 30 for
    ArTaxOr / DIOR / NEU-DET / UODD, overridable with ``--fixed-epochs``).  This
    is the like-for-like protocol, and it is derived from the ``scalars.json``
    of runs that already exist, so switching does **not** require retraining.
"""
import argparse
import csv
import json
from pathlib import Path
from statistics import mean, stdev


DATASETS = ('ArTaxOr', 'clipart1k', 'DIOR', 'FISH', 'NEU-DET', 'UODD')
STAGES = ('baseline', 'ffcp', 'ffcp_chsd', 'full')
SHOTS = ('1', '5', '10')
SEEDS = ('3407', '3408', '3409')


def _metric(record, suffixes):
    for key, value in record.items():
        if any(key == suffix or key.endswith('/' + suffix)
               for suffix in suffixes):
            try:
                return float(value)
            except (TypeError, ValueError):
                pass
    return None


_EPOCH_WARNED = False


def read_scalars(path):
    """One row per validation record, with a robustly determined epoch.

    ``scalars.json`` in this project does not always carry an ``epoch`` field,
    and without it the fixed-epoch selection cannot match anything.  When the
    field is missing the record index is used: ``val_interval=1`` writes one
    validation line per epoch in epoch order starting at 1, so the k-th record
    *is* epoch k.  A one-time warning records that the inference was used.
    """
    global _EPOCH_WARNED
    rows = []
    with path.open('r', encoding='utf-8') as handle:
        for line in handle:
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(item, dict):
                continue
            epoch = item.get('epoch')
            m_ap = _metric(item, ('bbox_mAP', 'coco/bbox_mAP'))
            if m_ap is None:
                continue
            if epoch is None:
                epoch = len(rows) + 1
                if not _EPOCH_WARNED:
                    _EPOCH_WARNED = True
                    print('[warn] scalars.json carries no `epoch` field; the '
                          'epoch is taken from the record order (one validation '
                          'line per epoch, which is what val_interval=1 writes)')
            try:
                epoch = int(epoch)
            except (TypeError, ValueError):
                epoch = len(rows) + 1
            rows.append({
                'epoch': epoch,
                'mAP': m_ap,
                'mAP50': _metric(item, ('bbox_mAP_50', 'coco/bbox_mAP_50')),
                'mAP75': _metric(item, ('bbox_mAP_75', 'coco/bbox_mAP_75')),
            })
    return rows


# the paper fixes the schedule per dataset: clipart1k and DeepFish are fine-tuned
# for five epochs, the other four datasets for thirty (the same rule is encoded
# in tools/s2h/gen_s2h_configs.py)
FIVE_EPOCH_DATASETS = {'clipart1k', 'FISH'}
DEFAULT_FIXED_EPOCHS = {'clipart1k': 5, 'FISH': 5, 'ArTaxOr': 30, 'DIOR': 30,
                        'NEU-DET': 30, 'UODD': 30}


def resolve_fixed_epoch(dataset: str, overrides: dict) -> int:
    """Pre-declared epoch of a dataset; ``--fixed-epochs`` takes precedence."""
    if dataset in overrides:
        return int(overrides[dataset])
    if dataset in DEFAULT_FIXED_EPOCHS:
        return DEFAULT_FIXED_EPOCHS[dataset]
    return 5 if dataset in FIVE_EPOCH_DATASETS else 30


def select_record(records, mode: str = 'best', fixed_epoch=None):
    """Pick the record to report: the best-mAP epoch or a pre-declared one.

    ``best`` reproduces the original behaviour; because ``val_dataloader`` reads
    ``annotations/test.json`` it selects the epoch *on the test set*.  ``fixed``
    reads the epoch the paper declares in advance, which is the honest protocol
    and can be derived from the ``scalars.json`` of runs that already exist.
    """
    if not records:
        return None
    if mode == 'fixed':
        for record in records:
            if record['epoch'] == fixed_epoch:
                return record
        return None
    return max(records, key=lambda item: item['mAP'])


def best_run(work, mode: str = 'best', fixed_epoch=None):
    candidates = sorted(work.glob('**/scalars.json'))
    if not candidates:
        return None
    records = []
    for path in candidates:
        records.extend(read_scalars(path))
    return select_record(records, mode, fixed_epoch)


def fmt(value):
    return '' if value is None else f'{value:.6f}'


def parse_args():
    parser = argparse.ArgumentParser('Summarize S2H ablation results')
    parser.add_argument('--root', default='cat_work_dir/ablation')
    parser.add_argument('--datasets', nargs='+', default=DATASETS)
    parser.add_argument('--stages', nargs='+', default=STAGES)
    parser.add_argument('--shots', nargs='+', default=SHOTS)
    parser.add_argument('--seeds', nargs='+', default=SEEDS)
    parser.add_argument('--epoch-mode', choices=['best', 'fixed'],
                        default='best',
                        help="'best' (default) reports the highest validation "
                             'mAP of a run - and since val_dataloader reads '
                             'annotations/test.json that is a test-selected '
                             "epoch; 'fixed' reads the pre-declared epoch "
                             '(5 for clipart1k / FISH, 30 otherwise)')
    parser.add_argument('--fixed-epochs', default='',
                        help="per-dataset epoch overrides for --epoch-mode "
                             "fixed, e.g. 'clipart1k=5,FISH=5,DIOR=30'")
    parser.add_argument('--out', default='work_dirs/s2h_ablation_summary.csv')
    return parser.parse_args()


def main():
    args = parse_args()
    root = Path(args.root)
    rows = []
    missing = []
    overrides = {}
    for item in (args.fixed_epochs or '').replace(' ', '').split(','):
        if '=' in item:
            key, value = item.split('=', 1)
            overrides[key] = int(value)

    for dataset in args.datasets:
        fixed_epoch = resolve_fixed_epoch(dataset, overrides) \
            if args.epoch_mode == 'fixed' else None
        for stage in args.stages:
            for shot in args.shots:
                values = []
                for seed in args.seeds:
                    work = root / dataset / stage / f'seed{seed}' / f'{shot}shot'
                    result = best_run(work, args.epoch_mode, fixed_epoch)
                    if result is None:
                        missing.append(f'{work} (epoch {fixed_epoch})'
                                       if args.epoch_mode == 'fixed'
                                       else str(work))
                        continue
                    row = dict(dataset=dataset, stage=stage, shot=shot,
                               seed=seed, **result)
                    rows.append(row)
                    values.append(row)
                if values:
                    aggregate = dict(dataset=dataset, stage=stage, shot=shot,
                                     seed='mean_std', epoch='')
                    for metric in ('mAP', 'mAP50', 'mAP75'):
                        nums = [v[metric] for v in values if v[metric] is not None]
                        aggregate[metric] = mean(nums) if nums else None
                        aggregate[f'{metric}_std'] = (
                            stdev(nums) if len(nums) > 1 else 0.0
                        ) if nums else None
                    rows.append(aggregate)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fields = ('dataset', 'stage', 'shot', 'seed', 'epoch',
              'mAP', 'mAP_std', 'mAP50', 'mAP50_std', 'mAP75', 'mAP75_std')
    with out.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: fmt(value) if key in (
                'mAP', 'mAP_std', 'mAP50', 'mAP50_std', 'mAP75', 'mAP75_std')
                             else value for key, value in row.items()})
    print(f'wrote {len(rows)} rows -> {out}')
    if missing:
        print(f'missing/unreadable runs: {len(missing)}')
        for path in missing:
            print(f'  [MISS] {path}')
    expected = len(args.datasets) * len(args.stages) * len(args.shots) * len(args.seeds)
    observed = sum(1 for row in rows if row['seed'] != 'mean_std')
    print(f'observed runs: {observed}/{expected}')


if __name__ == '__main__':
    main()
